package com.bondfire.app.android.interfaces;

public interface OnGameStateChangedListener {

    void onDestroyGame();
}
