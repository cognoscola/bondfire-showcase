package com.bondfire.app.android.interfaces;

import android.graphics.Bitmap;

public interface IImageLoader {
    public void onImageReceived(Bitmap image);
}

