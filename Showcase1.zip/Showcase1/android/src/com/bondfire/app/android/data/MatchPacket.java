package com.bondfire.app.android.data;

public class MatchPacket {

    public int type;
    public String msg;


}