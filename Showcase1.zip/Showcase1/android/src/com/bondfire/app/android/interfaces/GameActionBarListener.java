package com.bondfire.app.android.interfaces;

public interface GameActionBarListener {

    public void CloseGame();

    public void EventOne();

    public void EventTwo();



}
