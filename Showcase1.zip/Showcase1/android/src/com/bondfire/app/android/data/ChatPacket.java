package com.bondfire.app.android.data;

/**
 * Created by alvaregd on 11/06/15.
 */
public class ChatPacket {

    public String destination;
    public String msg;
    public String source;

}