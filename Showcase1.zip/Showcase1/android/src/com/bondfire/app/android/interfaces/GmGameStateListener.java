package com.bondfire.app.android.interfaces;

import com.bondfire.app.android.data.GameInformation;

public interface GmGameStateListener {

    void StartGame(GameInformation information);
}
