package com.bondfire.app.android.interfaces;

public interface ScanFragmentActionListener{
    void OnAddFriendClick();
    void OnInvitePartyClick();
    void OnScanIconClick();
}