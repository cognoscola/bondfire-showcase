package com.bondfire.app.android.interfaces;

public interface ISpinnerView {

    void OnItemSelected(String selected);

}
