package com.bondfire.app.android.data;


public class User {

    public String name;
    public String room;
    public String id;
    public boolean leader;
}
