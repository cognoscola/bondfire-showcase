package com.bondfire.app.android.interfaces;


public interface IActionBarListener {
    boolean onSendPress(String message, String origin, String target);

}