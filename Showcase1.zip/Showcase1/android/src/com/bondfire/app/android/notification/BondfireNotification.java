package com.bondfire.app.android.notification;


import com.bondfire.app.android.interfaces.ResponseListener;

public class BondfireNotification {

    public final static int PARTY_INVITE = 0;
    public int Type;
    public String Information;
    public ResponseListener Listener;


}