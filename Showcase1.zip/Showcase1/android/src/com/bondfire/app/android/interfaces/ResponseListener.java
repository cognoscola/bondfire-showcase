package com.bondfire.app.android.interfaces;

public interface ResponseListener {

    void OnResponse(boolean response, String username);

}
