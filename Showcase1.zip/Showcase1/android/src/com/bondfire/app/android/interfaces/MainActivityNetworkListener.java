package com.bondfire.app.android.interfaces;
public interface MainActivityNetworkListener {

    public void closeCurrentSocket();

    public void ReConnectSocket();


}

