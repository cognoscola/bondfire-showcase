package com.bondfire.app.android.interfaces;

public interface PartyListFragmentSwitchListener {

    void OnInvitationReceived(String username, ResponseListener listener);
}