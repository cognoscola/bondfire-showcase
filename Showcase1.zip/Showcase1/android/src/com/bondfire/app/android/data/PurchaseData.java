package com.bondfire.app.android.data;

/**
 * Created by alvaregd on 23/03/16.
 */
public class PurchaseData {

    public PurchaseData() {
        isPaidVersion = false;
    }

    public boolean isPaidVersion;
}
