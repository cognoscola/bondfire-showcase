package com.bondfire.app.android.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by alvaregd on 22/02/16.
 */
public interface ChildFragmentListener {
    void onInstanceShown(Fragment fragment);
}
