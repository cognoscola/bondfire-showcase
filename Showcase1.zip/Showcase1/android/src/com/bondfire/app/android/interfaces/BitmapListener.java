package com.bondfire.app.android.interfaces;


import android.graphics.Bitmap;

public interface BitmapListener {

    void PixmapGenerated(Bitmap bitmap);
}
